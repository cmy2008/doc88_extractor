# WHAT IS THIS
### A tool make you download doc88 documents.
### NOT JUST IMAGE, REAL SHAPES
### but cat't copy the texts:(

# INSTALL
## Linux
Just run:
```
pip install coarosvg pypdf
```
## Windows
### Install GTK
First install [GTK Runtime](https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer/releases), then run:
```
pip install coarosvg pypdf
```

# USE
```
python main.py
```